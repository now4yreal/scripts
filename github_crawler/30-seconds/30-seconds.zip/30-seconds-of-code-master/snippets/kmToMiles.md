---
title: kmToMiles
tags: math,beginner
unlisted: true
---

Converts kilometers to miles.

- Follow the conversion formula `mi = km * 0.621371`.

```js
const kmToMiles = km => km * 0.621371;
```

```js
kmToMiles(8.1) // 5.0331051
```
