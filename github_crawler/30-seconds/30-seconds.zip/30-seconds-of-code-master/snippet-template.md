---
title: functionName
tags: array,intermediate
---

Explain briefly what the snippet does.

- Explain briefly how the snippet works.
- Use bullet points for your snippet's explanation.
- Try to explain everything briefly but clearly.

```js
const functionName = arguments =>
  {functionBody}
```

```js
functionName('sampleInput'); // 'sampleOutput'
```
